# Rona Invite — Website Jualan Undangan Digital

Website statis yang siap dipasang di GitHub Pages.

## 1. Ganti nomor WhatsApp
Buka `script.js`, lalu ubah:

```js
const WHATSAPP = "6281234567890";
```

Contoh nomor Indonesia 0812xxxx menjadi `62812xxxx`.

## 2. Ganti nama toko
Di `index.html`, cari `Rona Invite` dan ubah sesuai nama brand kamu.
Di `script.js`, ubah juga:

```js
const STORE_NAME = "Rona Invite";
```

## 3. Upload ke GitHub
1. Buat repository baru, misalnya `undangan-digital`.
2. Upload `index.html`, `style.css`, dan `script.js`.
3. Commit.
4. Buka **Settings → Pages**.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch `main` dan folder `/ (root)`.
7. Save.
8. Setelah selesai, link biasanya berbentuk:
   `https://USERNAME.github.io/undangan-digital/`

## Catatan
Harga, nama tema, teks, dan warna bisa diubah langsung di `index.html` dan `style.css`.
