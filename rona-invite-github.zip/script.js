// ===============================
// PENGATURAN TOKO
// Ganti nomor di bawah dengan nomor WhatsApp kamu.
// Format internasional tanpa tanda +, contoh: 6281234567890
// ===============================
const WHATSAPP = "6281234567890";
const STORE_NAME = "Rona Invite";

function waLink(theme = "undangan digital") {
  const message = `Halo ${STORE_NAME}, saya tertarik dengan ${theme}. Mohon info cara pemesanan dan detailnya.`;
  return `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(message)}`;
}

document.querySelectorAll("[data-theme]").forEach(btn => {
  btn.addEventListener("click", () => {
    window.open(waLink(btn.dataset.theme), "_blank");
  });
});

document.getElementById("ctaWa").href = waLink("undangan digital");
document.getElementById("floatWa").href = waLink("undangan digital");

document.querySelectorAll(".filter").forEach(filter => {
  filter.addEventListener("click", () => {
    document.querySelectorAll(".filter").forEach(x => x.classList.remove("active"));
    filter.classList.add("active");
    const category = filter.dataset.filter;
    document.querySelectorAll(".theme-card").forEach(card => {
      card.classList.toggle("hidden", category !== "all" && card.dataset.category !== category);
    });
  });
});

document.querySelector(".menu").addEventListener("click", () => {
  const nav = document.querySelector(".nav nav");
  nav.style.display = nav.style.display === "flex" ? "" : "flex";
  nav.style.position = "absolute";
  nav.style.top = "78px";
  nav.style.left = "0";
  nav.style.right = "0";
  nav.style.padding = "20px 7%";
  nav.style.background = "#fffdf9";
  nav.style.flexDirection = "column";
  nav.style.borderBottom = "1px solid #eeeae4";
});

document.getElementById("year").textContent = new Date().getFullYear();
